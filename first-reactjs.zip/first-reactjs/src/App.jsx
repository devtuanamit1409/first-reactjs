import "./App.css";
import Header from "./components/Header";
import { Route, Routes } from "react-router-dom";
import Home from "./pages/Home";
import InteriorDesgin from "./pages/InteriorDesgin";
import DetailInteriorDesign from "./pages/DetailInteriorDesign";
import testTodoClick from "./pages/testTodoClick";

function App() {
  return (
    <>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/thiet-ke-noi-that" element={<InteriorDesgin />} />
        <Route
          path="/thiet-ke-noi-that/:slug"
          element={<DetailInteriorDesign />}
        />
        <Route path="/test-to-do-click" element={testTodoClick} />
      </Routes>
    </>
  );
}

export default App;
