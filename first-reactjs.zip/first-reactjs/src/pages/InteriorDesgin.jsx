import Seo from "../components/Seo";
const InteriorDesgin = () => {
  return (
    <>
      <Seo />
      <h1>Thiết kế nội thất</h1>
    </>
  );
};

export default InteriorDesgin;
