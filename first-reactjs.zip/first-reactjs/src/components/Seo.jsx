import React from "react";
import { Helmet } from "react-helmet";

const Seo = () => {
  return (
    <>
      <Helmet>
        <title>dsadsadsa</title>
      </Helmet>
    </>
  );
};

export default Seo;
